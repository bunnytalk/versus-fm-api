require('dotenv').config();
const express = require('express');
const cors = require('cors');
const session = require('express-session');
const axios = require('axios');

const app = express();
const PORT = process.env.PORT || 3000;

// ─── MIDDLEWARE ───────────────────────────────────────────────────────────────

app.use(express.json());

app.use(cors({
  origin: process.env.FRONTEND_URL,
  credentials: true,
}));

app.use(session({
  secret: process.env.SESSION_SECRET || 'versus-fm-secret',
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: process.env.NODE_ENV === 'production',
    maxAge: 1000 * 60 * 60 * 24, // 24 hours
  },
}));

// ─── SPOTIFY CONFIG ───────────────────────────────────────────────────────────

const SPOTIFY_CLIENT_ID = process.env.SPOTIFY_CLIENT_ID;
const SPOTIFY_CLIENT_SECRET = process.env.SPOTIFY_CLIENT_SECRET;
const REDIRECT_URI = process.env.REDIRECT_URI;

const SPOTIFY_SCOPES = [
  'user-read-private',
  'user-read-email',
  'playlist-read-private',
  'playlist-read-collaborative',
  'user-top-read',
  'user-library-read',
].join(' ');

// ─── HELPERS ──────────────────────────────────────────────────────────────────

// Refresh access token if expired
async function getValidToken(req) {
  const { access_token, refresh_token, token_expires_at } = req.session;

  if (!access_token) throw new Error('Not authenticated');

  // If token is still valid, return it
  if (Date.now() < token_expires_at - 60000) {
    return access_token;
  }

  // Token expired — refresh it
  const response = await axios.post('https://accounts.spotify.com/api/token',
    new URLSearchParams({
      grant_type: 'refresh_token',
      refresh_token,
    }),
    {
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        Authorization: `Basic ${Buffer.from(`${SPOTIFY_CLIENT_ID}:${SPOTIFY_CLIENT_SECRET}`).toString('base64')}`,
      },
    }
  );

  req.session.access_token = response.data.access_token;
  req.session.token_expires_at = Date.now() + response.data.expires_in * 1000;
  if (response.data.refresh_token) {
    req.session.refresh_token = response.data.refresh_token;
  }

  return req.session.access_token;
}

// Spotify API call helper
async function spotifyGet(url, token, params = {}) {
  const response = await axios.get(url, {
    headers: { Authorization: `Bearer ${token}` },
    params,
  });
  return response.data;
}

// Auth middleware
function requireAuth(req, res, next) {
  if (!req.session.access_token) {
    return res.status(401).json({ error: 'Not authenticated' });
  }
  next();
}

// ─── AUTH ROUTES ──────────────────────────────────────────────────────────────

// Step 1 — redirect to Spotify login
app.get('/auth/login', (req, res) => {
  const params = new URLSearchParams({
    client_id: SPOTIFY_CLIENT_ID,
    response_type: 'code',
    redirect_uri: REDIRECT_URI,
    scope: SPOTIFY_SCOPES,
    show_dialog: true,
  });
  res.redirect(`https://accounts.spotify.com/authorize?${params}`);
});

// Step 2 — Spotify redirects back here with a code
app.get('/auth/callback', async (req, res) => {
  const { code, error } = req.query;

  if (error) {
    return res.redirect(`${process.env.FRONTEND_URL}?auth_error=${error}`);
  }

  try {
    const response = await axios.post('https://accounts.spotify.com/api/token',
      new URLSearchParams({
        grant_type: 'authorization_code',
        code,
        redirect_uri: REDIRECT_URI,
      }),
      {
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          Authorization: `Basic ${Buffer.from(`${SPOTIFY_CLIENT_ID}:${SPOTIFY_CLIENT_SECRET}`).toString('base64')}`,
        },
      }
    );

    // Store tokens in session
    req.session.access_token = response.data.access_token;
    req.session.refresh_token = response.data.refresh_token;
    req.session.token_expires_at = Date.now() + response.data.expires_in * 1000;

    // Redirect back to the frontend app
    res.redirect(`${process.env.FRONTEND_URL}?auth=success`);
  } catch (err) {
    console.error('Auth callback error:', err.response?.data || err.message);
    res.redirect(`${process.env.FRONTEND_URL}?auth_error=token_exchange_failed`);
  }
});

// Log out
app.get('/auth/logout', (req, res) => {
  req.session.destroy();
  res.json({ success: true });
});

// Check if logged in
app.get('/auth/status', (req, res) => {
  res.json({ authenticated: !!req.session.access_token });
});

// ─── USER ROUTES ──────────────────────────────────────────────────────────────

// GET /api/me — current user profile
app.get('/api/me', requireAuth, async (req, res) => {
  try {
    const token = await getValidToken(req);
    const data = await spotifyGet('https://api.spotify.com/v1/me', token);

    res.json({
      id: data.id,
      name: data.display_name,
      email: data.email,
      avatar: data.images?.[0]?.url || null,
      plan: data.product, // 'free' or 'premium'
    });
  } catch (err) {
    console.error('GET /api/me error:', err.message);
    res.status(500).json({ error: 'Failed to fetch user profile' });
  }
});

// ─── PLAYLIST ROUTES ──────────────────────────────────────────────────────────

// GET /api/playlists — get all user playlists including Liked Songs
app.get('/api/playlists', requireAuth, async (req, res) => {
  try {
    const token = await getValidToken(req);

    // Get Liked Songs count
    const likedData = await spotifyGet('https://api.spotify.com/v1/me/tracks', token, { limit: 1 });

    // Get user playlists (paginate up to 50)
    const playlistData = await spotifyGet('https://api.spotify.com/v1/me/playlists', token, { limit: 50 });

    const playlists = [
      // Liked Songs always first
      {
        id: 'liked',
        name: 'Liked Songs',
        count: likedData.total,
        image: null,
        type: 'liked',
      },
      // Then user playlists
      ...playlistData.items.map(p => ({
        id: p.id,
        name: p.name,
        count: p.tracks.total,
        image: p.images?.[0]?.url || null,
        type: 'playlist',
      })),
    ];

    res.json(playlists);
  } catch (err) {
    console.error('GET /api/playlists error:', err.message);
    res.status(500).json({ error: 'Failed to fetch playlists' });
  }
});

// GET /api/playlist/:id/tracks — get tracks with play counts
app.get('/api/playlist/:id/tracks', requireAuth, async (req, res) => {
  try {
    const token = await getValidToken(req);
    const { id } = req.params;
    const limit = Math.min(parseInt(req.query.limit) || 128, 128);

    // Get user's top tracks for play count data (up to 50 at a time, 3 time ranges)
    const [shortTerm, mediumTerm, longTerm] = await Promise.all([
      spotifyGet('https://api.spotify.com/v1/me/top/tracks', token, { limit: 50, time_range: 'short_term' }),
      spotifyGet('https://api.spotify.com/v1/me/top/tracks', token, { limit: 50, time_range: 'medium_term' }),
      spotifyGet('https://api.spotify.com/v1/me/top/tracks', token, { limit: 50, time_range: 'long_term' }),
    ]);

    // Build play count map — rank position used as proxy for plays
    // Higher rank = more plays. We weight long_term more heavily.
    const playCounts = {};
    const addToPlayCounts = (items, weight) => {
      items.forEach((track, idx) => {
        const score = (items.length - idx) * weight;
        playCounts[track.id] = (playCounts[track.id] || 0) + score;
      });
    };
    addToPlayCounts(longTerm.items, 3);
    addToPlayCounts(mediumTerm.items, 2);
    addToPlayCounts(shortTerm.items, 1);

    // Fetch tracks from the playlist
    let tracks = [];

    if (id === 'liked') {
      // Liked Songs
      let offset = 0;
      while (tracks.length < limit) {
        const batch = await spotifyGet('https://api.spotify.com/v1/me/tracks', token, {
          limit: Math.min(50, limit - tracks.length),
          offset,
        });
        tracks.push(...batch.items.map(item => item.track));
        if (!batch.next) break;
        offset += 50;
      }
    } else {
      // Regular playlist
      let offset = 0;
      while (tracks.length < limit) {
        const batch = await spotifyGet(`https://api.spotify.com/v1/playlists/${id}/tracks`, token, {
          limit: Math.min(50, limit - tracks.length),
          offset,
          fields: 'next,items(track(id,name,artists,album,duration_ms,preview_url))',
        });
        tracks.push(...batch.items.map(item => item.track).filter(Boolean));
        if (!batch.next) break;
        offset += 50;
      }
    }

    // Format and sort by play count (descending)
    const formatted = tracks
      .filter(t => t && t.id)
      .map(track => ({
        id: track.id,
        name: track.name,
        artist: track.artists?.[0]?.name || 'Unknown',
        album: track.album?.name || '',
        image: track.album?.images?.[0]?.url || null,
        plays: playCounts[track.id] || 0,
        duration_ms: track.duration_ms,
        preview_url: track.preview_url || null,
      }))
      .sort((a, b) => b.plays - a.plays)
      .slice(0, limit);

    // Add seed numbers based on sorted order
    formatted.forEach((track, idx) => {
      track.seed = idx + 1;
    });

    res.json(formatted);
  } catch (err) {
    console.error('GET /api/playlist/:id/tracks error:', err.message);
    res.status(500).json({ error: 'Failed to fetch tracks' });
  }
});

// ─── DAILY PICK ───────────────────────────────────────────────────────────────

// Simple daily pick — two global songs that rotate every day
// In a real app you'd store these in a database
const DAILY_PICKS = [
  { songA: { name: 'Blinding Lights', artist: 'The Weeknd' }, songB: { name: 'As It Was', artist: 'Harry Styles' } },
  { songA: { name: 'Anti-Hero', artist: 'Taylor Swift' }, songB: { name: 'Flowers', artist: 'Miley Cyrus' } },
  { songA: { name: 'Heat Waves', artist: 'Glass Animals' }, songB: { name: 'Levitating', artist: 'Dua Lipa' } },
  { songA: { name: 'Cruel Summer', artist: 'Taylor Swift' }, songB: { name: 'Stay', artist: 'Kid LAROI' } },
  { songA: { name: 'Golden Hour', artist: 'JVKE' }, songB: { name: 'Bad Habit', artist: 'Steve Lacy' } },
  { songA: { name: 'About Damn Time', artist: 'Lizzo' }, songB: { name: 'Good 4 U', artist: 'Olivia Rodrigo' } },
  { songA: { name: 'Unholy', artist: 'Sam Smith' }, songB: { name: 'Industry Baby', artist: 'Lil Nas X' } },
];

app.get('/api/daily', (req, res) => {
  const today = new Date();
  const dayOfYear = Math.floor((today - new Date(today.getFullYear(), 0, 0)) / 86400000);
  const pick = DAILY_PICKS[dayOfYear % DAILY_PICKS.length];
  res.json({ ...pick, date: today.toISOString().split('T')[0] });
});

// ─── HEALTH CHECK ─────────────────────────────────────────────────────────────

app.get('/', (req, res) => {
  res.json({ status: 'Versus.fm API is running', version: '1.0.0' });
});

// ─── START SERVER ─────────────────────────────────────────────────────────────

app.listen(PORT, () => {
  console.log(`✅ Versus.fm API running on port ${PORT}`);
});
