# Versus.fm API

Backend server for Versus.fm. Handles Spotify OAuth and all API calls.

## Deploy to Render (step by step)

### 1. Push this folder to GitHub

1. Go to github.com and create a new repo called `versus-fm-api`
2. Upload all these files to it

### 2. Create a Render account

1. Go to render.com
2. Sign up with your GitHub account

### 3. Create a new Web Service on Render

1. Click **New** → **Web Service**
2. Connect your GitHub repo `versus-fm-api`
3. Set these settings:
   - **Name:** versus-fm-api
   - **Runtime:** Node
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
   - **Plan:** Free

### 4. Add Environment Variables on Render

In your Render service, go to **Environment** and add these:

| Key | Value |
|-----|-------|
| `SPOTIFY_CLIENT_ID` | Your Spotify Client ID |
| `SPOTIFY_CLIENT_SECRET` | Your NEW Spotify Client Secret (after rotating) |
| `REDIRECT_URI` | `https://your-render-url.onrender.com/auth/callback` |
| `FRONTEND_URL` | `https://moonlit-sprite-41d3b7.netlify.app` |
| `SESSION_SECRET` | Any long random string e.g. `versus-fm-super-secret-2025` |
| `NODE_ENV` | `production` |

### 5. Update Spotify Dashboard

Once Render gives you a URL (like `https://versus-fm-api.onrender.com`):

1. Go to developer.spotify.com/dashboard
2. Click your app → Edit Settings
3. Add to Redirect URIs: `https://versus-fm-api.onrender.com/auth/callback`
4. Save

### 6. Done!

Your API will be live at `https://versus-fm-api.onrender.com`

Test it by visiting: `https://versus-fm-api.onrender.com/` — you should see:
```json
{ "status": "Versus.fm API is running", "version": "1.0.0" }
```

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/auth/login` | Redirect to Spotify login |
| GET | `/auth/callback` | Spotify OAuth callback |
| GET | `/auth/logout` | Log out |
| GET | `/auth/status` | Check if logged in |
| GET | `/api/me` | Current user profile |
| GET | `/api/playlists` | User's playlists |
| GET | `/api/playlist/:id/tracks?limit=128` | Tracks with play counts |
| GET | `/api/daily` | Today's daily pick songs |
